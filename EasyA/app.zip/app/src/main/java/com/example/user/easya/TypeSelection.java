package com.example.user.easya;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TypeSelection extends AppCompatActivity {

    String username = "default username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type_selection);

        username = getIntent().getExtras().getString("username");

        TextView tv = (TextView) findViewById(R.id.greeting);
        tv.setText("Hello "+username+"!");
    }
}
