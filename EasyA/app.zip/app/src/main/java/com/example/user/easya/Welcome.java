package com.example.user.easya;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.core.Context;

public class Welcome extends AppCompatActivity {

    String username = "default";
    private Button signupButton ;
    private Firebase mRef;
    private static int userNo;
    public EditText et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        Firebase.setAndroidContext(this);

        et = (EditText) findViewById(R.id.usernameInputField);
        username = et.getText().toString();

        mRef = new Firebase("https://easya-c2f38.firebaseio.com/");//link to my database


    }

    public void signUp(View view){

        Toast.makeText(this, username+" !", Toast.LENGTH_LONG).show();

        signupButton = (Button) findViewById(R.id.signupButt);
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Firebase mRefChild = mRef.child(username);
            }


        });
    }

    public void goToNext(View view){


        Intent i = new Intent(Welcome.this, TypeSelection.class);
        i.putExtra("username", username);
        startActivity(i);
    }
}
