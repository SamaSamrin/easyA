package com.example.user.easya;

import android.app.Application;

import com.firebase.client.Firebase;

/**
 * Created by User on 04-Dec-16.
 */

public class EasyA extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Firebase.setAndroidContext(this);
    }
}
